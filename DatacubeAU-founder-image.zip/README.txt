Upload Prova.png to the public/ directory in DATACUBEAU/Datacube_Au. The About page feature branch already references /Prova.png. Once the image is in public/, remove the old public/avater.png file.
